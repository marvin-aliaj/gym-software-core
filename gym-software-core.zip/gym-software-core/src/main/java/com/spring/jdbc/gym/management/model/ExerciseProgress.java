package com.spring.jdbc.gym.management.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExerciseProgress {
    private String id;
    private int set;
    private int reps;
    private BigDecimal weight;
    private String exerciseId;
    private String trainingPlanId;
    @JsonProperty
    private String cDate;
    @JsonProperty
    private String mDate;
}
